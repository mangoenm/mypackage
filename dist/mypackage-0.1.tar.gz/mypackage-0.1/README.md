# mypackage
This library was created as an example